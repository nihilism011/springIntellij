package com.mySpringServer.myPage.dao;

import java.util.HashMap;
import java.util.Objects;

public interface PayService {
    HashMap<String, Object> searchPayList();
}
